import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Coffee, Droplets, CupSoda, GlassWater, Power, Flame, ChevronRight } from 'lucide-react';
import svgPaths from '../imports/svg-6o7dapr61y';

function HistoryBtn({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[326px] size-[25px] top-[81px] cursor-pointer hover:opacity-80 transition-opacity"} data-name="History">
      <div className="absolute left-[-17px] size-[60px] top-[-18px]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 60 60">
          <foreignObject height="68" width="68" x="-4" y="-4">
            <div style={{ backdropFilter: "blur(2px)", clipPath: "url(#bgblur_0_1_42_clip_path)", height: "100%", width: "100%" }} xmlns="http://www.w3.org/1999/xhtml" />
          </foreignObject>
          <circle cx="30" cy="30" fill="#D9D9D9" fillOpacity="0.2" r="30" />
          <defs>
            <clipPath id="bgblur_0_1_42_clip_path" transform="translate(4 4)">
              <circle cx="30" cy="30" r="30" />
            </clipPath>
          </defs>
        </svg>
      </div>
      <div className="absolute inset-[14.02%_72.73%_70.83%_12.12%]">
        <div className="absolute inset-[-28.6%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 5.95455 5.95454">
            <path d={svgPaths.p81e0800} stroke="#D9D9D9" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.8" strokeWidth="2.16667" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.33%]">
        <div className="absolute inset-[-5.2%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23 23">
            <path d={svgPaths.pa2687e0} stroke="#D9D9D9" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.8" strokeWidth="2.16667" />
          </svg>
        </div>
      </div>
      <div className="absolute bottom-[32.32%] left-[50.01%] right-[32.33%] top-1/4">
        <div className="absolute inset-[-10.15%_-24.53%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6.58302 12.8376">
            <path d={svgPaths.p2726b370} stroke="#D9D9D9" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.8" strokeWidth="2.16667" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function MeBtn({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[52px] size-[26px] top-[80px] cursor-pointer hover:opacity-80 transition-opacity"} data-name="Me">
      <div className="absolute left-[-17px] size-[60px] top-[-17px]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 60 60">
          <foreignObject height="68" width="68" x="-4" y="-4">
            <div style={{ backdropFilter: "blur(2px)", clipPath: "url(#bgblur_me_clip)", height: "100%", width: "100%" }} xmlns="http://www.w3.org/1999/xhtml" />
          </foreignObject>
          <circle cx="30" cy="30" fill="#D9D9D9" fillOpacity="0.2" r="30" />
          <defs>
            <clipPath id="bgblur_me_clip" transform="translate(4 4)">
              <circle cx="30" cy="30" r="30" />
            </clipPath>
          </defs>
        </svg>
      </div>
      <div className="absolute inset-[8.33%]">
        <div className="absolute inset-[-4.62%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.6667 23.6667">
            <path clipRule="evenodd" d={svgPaths.p178d6e00} fillRule="evenodd" stroke="#D9D9D9" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.8" strokeWidth="2" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[27.08%_39.58%_52.08%_39.58%]">
        <div className="absolute inset-[-18.46%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 7.41667 7.41667">
            <path d={svgPaths.pf0f95f0} stroke="#D9D9D9" strokeLinejoin="round" strokeOpacity="0.8" strokeWidth="2" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[60.42%_20.88%_20.14%_20.88%]">
        <div className="absolute inset-[-19.78%_-6.6%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.1422 7.05487">
            <path d={svgPaths.p38d41000} stroke="#D9D9D9" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.8" strokeWidth="2" />
          </svg>
        </div>
      </div>
    </div>
  );
}

const mockDevices = [
  { id: 1, name: '一楼大厅开水器', icon: Coffee, count: 12, bg: 'linear-gradient(142.745deg, rgb(217, 236, 97) 100%, rgb(197, 214, 87) 0%)', top: 437, textColor: 'text-[#1a1a1a]' },
  { id: 2, name: '二楼茶水间设备', icon: Droplets, count: 5, bg: '#e95800', top: 547, textColor: 'text-white' },
  { id: 3, name: '三楼走廊饮水机', icon: CupSoda, count: 28, bg: 'linear-gradient(142.745deg, rgb(255, 139, 85) 100%, rgb(241, 125, 77) 0%)', top: 664, textColor: 'text-white' },
  { id: 4, name: '会议室专用水吧', icon: GlassWater, count: 3, bg: 'rgba(185,143,244,0.2)', top: 773, textColor: 'text-white' },
];

export default function App() {
  const [activeCardId, setActiveCardId] = useState<number | null>(null);
  const [mainStatus, setMainStatus] = useState(false);
  const [devicePowers, setDevicePowers] = useState<Record<number, boolean>>({
    1: true,
    2: false,
    3: true,
    4: false
  });

  const togglePower = (id: number) => {
    setDevicePowers(prev => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <div className="min-h-screen bg-neutral-950 flex justify-center items-center py-8 px-4 font-sans">
      <div className="w-[393px] h-[852px] bg-[#1a1a1a] relative rounded-[50px] overflow-x-hidden overflow-y-auto shadow-2xl ring-4 ring-neutral-800 scrollbar-hide">
        
        {/* Top Gradient Background */}
        <div className="absolute h-[306px] left-[14px] top-[-118px] w-[374px] pointer-events-none z-0">
          <div className="absolute inset-[-32.68%_-26.74%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 574 506">
              <g filter="url(#filter0_f_1_33)">
                <path d={svgPaths.p17238570} fill="url(#paint0_linear_1_33)" fillOpacity="0.5" />
              </g>
              <defs>
                <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="506" id="filter0_f_1_33" width="574" x="0" y="0">
                  <feFlood floodOpacity="0" result="BackgroundImageFix" />
                  <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                  <feGaussianBlur result="effect1_foregroundBlur_1_33" stdDeviation="50" />
                </filter>
                <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_33" x1="287" x2="287" y1="100" y2="406">
                  <stop offset="0.00961538" stopColor="#91EA94" />
                  <stop offset="0.580122" stopColor="#70AF56" />
                  <stop offset="0.865385" stopColor="#B46B6C" />
                </linearGradient>
              </defs>
            </svg>
          </div>
        </div>

        {/* Top Header Buttons */}
        <HistoryBtn />
        <MeBtn />

        {/* Central Dark Card - Balance Info */}
        <div className="absolute bg-[#1f222f] h-[175px] left-[28px] rounded-[40px] top-[217px] w-[345px] shadow-xl flex flex-col items-center justify-start pt-8 pb-4 z-10">
          <div className="text-gray-400 text-[13px] font-medium tracking-widest mb-2">当前余额 (元)</div>
          <div className="text-white text-[44px] font-bold tracking-tight leading-none">
            342.50
          </div>
        </div>

        {/* Blue/Purple Switch Card */}
        <div 
          onClick={() => setMainStatus(!mainStatus)}
          className="absolute bg-[#5647a7] h-[53px] left-[71px] rounded-[60px] top-[318px] w-[259px] z-20 flex items-center justify-between px-5 cursor-pointer shadow-[0_8px_20px_rgba(86,71,167,0.3)] hover:brightness-110 active:scale-95 transition-all"
        >
          <div className="flex items-center gap-2">
            <Flame className={`w-4 h-4 transition-colors ${mainStatus ? 'text-green-300' : 'text-white/70'}`} />
            <span className="text-white font-medium text-[15px]">当前状态: {mainStatus ? '打水中' : '空闲'}</span>
          </div>
          <div className={`w-12 h-6 rounded-full p-1 transition-colors duration-300 ${mainStatus ? 'bg-green-400' : 'bg-black/30'}`}>
            <motion.div 
              animate={{ x: mainStatus ? 24 : 0 }}
              className="w-4 h-4 rounded-full bg-white shadow-sm"
            />
          </div>
        </div>

        {/* Stacked Device Cards Container to ensure enough scrolling space */}
        <div className="relative w-full h-[700px] mt-[437px]">
          {mockDevices.map((device, index) => {
            const isExpanded = activeCardId === device.id;
            const isPowerOn = devicePowers[device.id];
            const Icon = device.icon;
            
            return (
              <motion.div
                key={device.id}
                className={`absolute w-[355px] h-[270px] left-[19px] rounded-[50px] shadow-[-10px_-10px_30px_15px_rgba(0,0,0,0.15)] cursor-pointer overflow-hidden flex flex-col ${device.textColor}`}
                style={{ 
                  background: device.bg,
                }}
                initial={false}
                animate={{
                  top: device.top - 437 - (isExpanded ? 30 : 0),
                  scale: isExpanded ? 1.02 : 1,
                  zIndex: isExpanded ? 50 : index,
                }}
                transition={{ type: "spring", stiffness: 350, damping: 25 }}
                onClick={() => setActiveCardId(isExpanded ? null : device.id)}
              >
                {/* Inner Shadow overlay */}
                <div className="absolute inset-0 rounded-[inherit] shadow-[inset_0px_1px_10px_0px_rgba(0,0,0,0.25)] pointer-events-none" />
                
                {/* Header Section (Always visible) */}
                <div className="px-6 pt-7 pb-4 flex items-center justify-between z-10 relative">
                  <div className="flex items-center gap-4">
                    <div className={`p-[14px] rounded-[20px] ${device.textColor === 'text-white' ? 'bg-white/20' : 'bg-black/10'} backdrop-blur-md shadow-sm`}>
                      <Icon size={26} strokeWidth={2.5} />
                    </div>
                    <span className="font-bold text-[19px] tracking-wide">{device.name}</span>
                  </div>
                  
                  <motion.div animate={{ rotate: isExpanded ? 90 : 0 }} className="opacity-60">
                    <ChevronRight size={24} />
                  </motion.div>
                </div>
                
                {/* Expandable Content Section */}
                <AnimatePresence>
                  {isExpanded && (
                    <motion.div 
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      transition={{ duration: 0.2, delay: 0.05 }}
                      className="px-7 flex-1 flex flex-col z-10 relative"
                    >
                      <div className="mt-3 flex-1">
                        <div className="text-[13px] opacity-70 font-medium tracking-wide mb-1">今日用水统计</div>
                        <div className="text-[44px] font-black tracking-tighter leading-none">
                          {device.count} <span className="text-[17px] font-medium opacity-80 tracking-normal ml-1">次</span>
                        </div>
                      </div>
                      
                      <div className={`flex items-center justify-between mt-auto mb-7 p-4 px-5 rounded-[28px] backdrop-blur-xl ${device.textColor === 'text-white' ? 'bg-black/20 shadow-inner' : 'bg-white/30 shadow-sm'}`}>
                        <div className="flex items-center gap-3 font-semibold text-[15px]">
                          <Power size={20} strokeWidth={2.5} />
                          <span>设备开关</span>
                        </div>
                        <div 
                          onClick={(e) => {
                            e.stopPropagation();
                            togglePower(device.id);
                          }}
                          className={`w-[52px] h-[30px] rounded-full p-[3px] transition-colors duration-300 cursor-pointer ${isPowerOn ? 'bg-[#34C759]' : 'bg-black/20'}`}
                        >
                          <motion.div 
                            animate={{ x: isPowerOn ? 22 : 0 }}
                            className="w-6 h-6 rounded-full bg-white shadow-md"
                          />
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
