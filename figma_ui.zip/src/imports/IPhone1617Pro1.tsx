import svgPaths from "./svg-6o7dapr61y";

function History({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[326px] size-[25px] top-[81px]"} data-name="History (历史记录)">
      <div className="absolute left-[-17px] size-[60px] top-[-18px]" data-name="记录">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 60 60">
          <foreignObject height="68" width="68" x="-4" y="-4">
            <div style={{ backdropFilter: "blur(2px)", clipPath: "url(#bgblur_0_1_42_clip_path)", height: "100%", width: "100%" }} xmlns="http://www.w3.org/1999/xhtml" />
          </foreignObject>
          <circle cx="30" cy="30" data-figma-bg-blur-radius="4" fill="var(--fill-0, #D9D9D9)" fillOpacity="0.2" id="è®°å½" r="30" />
          <defs>
            <clipPath id="bgblur_0_1_42_clip_path" transform="translate(4 4)">
              <circle cx="30" cy="30" r="30" />
            </clipPath>
          </defs>
        </svg>
      </div>
      <div className="absolute inset-[14.02%_72.73%_70.83%_12.12%]" data-name="Vector">
        <div className="absolute inset-[-28.6%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 5.95455 5.95454">
            <path d={svgPaths.p81e0800} id="Vector" stroke="var(--stroke-0, #D9D9D9)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.8" strokeWidth="2.16667" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.33%]" data-name="Vector">
        <div className="absolute inset-[-5.2%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23 23">
            <path d={svgPaths.pa2687e0} id="Vector" stroke="var(--stroke-0, #D9D9D9)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.8" strokeWidth="2.16667" />
          </svg>
        </div>
      </div>
      <div className="absolute bottom-[32.32%] left-[50.01%] right-[32.33%] top-1/4" data-name="Vector">
        <div className="absolute inset-[-10.15%_-24.53%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6.58302 12.8376">
            <path d={svgPaths.p2726b370} id="Vector" stroke="var(--stroke-0, #D9D9D9)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.8" strokeWidth="2.16667" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Me({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[52px] size-[26px] top-[80px]"} data-name="Me (我的)">
      <div className="absolute left-[-17px] size-[60px] top-[-17px]" data-name="头像">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 60 60">
          <foreignObject height="68" width="68" x="-4" y="-4">
            <div style={{ backdropFilter: "blur(2px)", clipPath: "url(#bgblur_0_1_42_clip_path)", height: "100%", width: "100%" }} xmlns="http://www.w3.org/1999/xhtml" />
          </foreignObject>
          <circle cx="30" cy="30" data-figma-bg-blur-radius="4" fill="var(--fill-0, #D9D9D9)" fillOpacity="0.2" id="è®°å½" r="30" />
          <defs>
            <clipPath id="bgblur_0_1_42_clip_path" transform="translate(4 4)">
              <circle cx="30" cy="30" r="30" />
            </clipPath>
          </defs>
        </svg>
      </div>
      <div className="absolute inset-[8.33%]" data-name="Vector">
        <div className="absolute inset-[-4.62%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.6667 23.6667">
            <path clipRule="evenodd" d={svgPaths.p178d6e00} fillRule="evenodd" id="Vector" stroke="var(--stroke-0, #D9D9D9)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.8" strokeWidth="2" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[27.08%_39.58%_52.08%_39.58%]" data-name="Vector">
        <div className="absolute inset-[-18.46%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 7.41667 7.41667">
            <path d={svgPaths.pf0f95f0} id="Vector" stroke="var(--stroke-0, #D9D9D9)" strokeLinejoin="round" strokeOpacity="0.8" strokeWidth="2" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[60.42%_20.88%_20.14%_20.88%]" data-name="Vector">
        <div className="absolute inset-[-19.78%_-6.6%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.1422 7.05487">
            <path d={svgPaths.p38d41000} id="Vector" stroke="var(--stroke-0, #D9D9D9)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.8" strokeWidth="2" />
          </svg>
        </div>
      </div>
    </div>
  );
}

export default function IPhone1617Pro() {
  return (
    <div className="bg-[#1a1a1a] relative size-full" data-name="iPhone 16 & 17 Pro - 1">
      <div className="absolute h-[306px] left-[14px] top-[-118px] w-[374px]" data-name="上部渐变">
        <div className="absolute inset-[-32.68%_-26.74%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 574 506">
            <g filter="url(#filter0_f_1_33)" id="ä¸é¨æ¸å">
              <path d={svgPaths.p17238570} fill="url(#paint0_linear_1_33)" fillOpacity="0.5" />
            </g>
            <defs>
              <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="506" id="filter0_f_1_33" width="574" x="0" y="0">
                <feFlood floodOpacity="0" result="BackgroundImageFix" />
                <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                <feGaussianBlur result="effect1_foregroundBlur_1_33" stdDeviation="50" />
              </filter>
              <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_33" x1="287" x2="287" y1="100" y2="406">
                <stop offset="0.00961538" stopColor="#91EA94" />
                <stop offset="0.580122" stopColor="#70AF56" />
                <stop offset="0.865385" stopColor="#B46B6C" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      </div>
      <History />
      <Me />
      <div className="absolute bg-[#1f222f] h-[175px] left-[28px] rounded-[40px] top-[217px] w-[345px]" data-name="深色卡片" />
      <div className="absolute bg-[#5647a7] h-[53px] left-[71px] rounded-[60px] top-[318px] w-[259px]" data-name="卡片内小卡片" />
      <div className="absolute h-[270px] left-[23px] pointer-events-none rounded-[50px] shadow-[-10px_-10px_30px_15px_rgba(0,0,0,0.25)] top-[437px] w-[355px]" data-name="设备卡片1">
        <div aria-hidden="true" className="absolute inset-0 rounded-[50px]" style={{ backgroundImage: "linear-gradient(142.745deg, rgb(217, 236, 97) 100%, rgb(197, 214, 87) 0%)" }} />
        <div className="absolute inset-0 rounded-[inherit] shadow-[inset_0px_1px_10px_0px_rgba(0,0,0,0.25)]" />
      </div>
      <div className="absolute h-[270px] left-[23px] pointer-events-none rounded-[50px] shadow-[-10px_-10px_30px_15px_rgba(0,0,0,0.25)] top-[547px] w-[355px]" data-name="设备卡片2">
        <div aria-hidden="true" className="absolute bg-[#e95800] inset-0 rounded-[50px]" />
        <div className="absolute inset-0 rounded-[inherit] shadow-[inset_0px_1px_10px_0px_rgba(0,0,0,0.25)]" />
      </div>
      <div className="absolute h-[270px] left-[23px] pointer-events-none rounded-[50px] shadow-[-10px_-10px_30px_15px_rgba(0,0,0,0.25)] top-[664px] w-[355px]" data-name="设备卡片3">
        <div aria-hidden="true" className="absolute inset-0 rounded-[50px]" style={{ backgroundImage: "linear-gradient(142.745deg, rgb(255, 139, 85) 100%, rgb(241, 125, 77) 0%)" }} />
        <div className="absolute inset-0 rounded-[inherit] shadow-[inset_0px_1px_10px_0px_rgba(0,0,0,0.25)]" />
      </div>
      <div className="absolute h-[270px] left-[23px] pointer-events-none rounded-[50px] shadow-[-10px_-10px_30px_15px_rgba(0,0,0,0.25)] top-[773px] w-[355px]" data-name="设备卡片4">
        <div aria-hidden="true" className="absolute bg-[rgba(185,143,244,0.2)] inset-0 rounded-[50px]" />
        <div className="absolute inset-0 rounded-[inherit] shadow-[inset_0px_1px_10px_0px_rgba(0,0,0,0.25)]" />
      </div>
    </div>
  );
}