
  # 开水软件UI设计

  This is a code bundle for 开水软件UI设计. The original project is available at https://www.figma.com/design/eTGWiskwbl0q373FskuQcJ/%E5%BC%80%E6%B0%B4%E8%BD%AF%E4%BB%B6UI%E8%AE%BE%E8%AE%A1.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  